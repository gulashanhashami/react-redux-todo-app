import axios from "axios";
import { useParams } from "react-router-dom";
import {useState, useEffect} from "react";


export const EditTodos=()=>{
    const [Data, setData]=useState();
    let { id } = useParams();
    useEffect(()=>{
    axios.get(`http://localhost:3001/todos/${id}`).then((res)=>{
        // console.log(res)
       setData(res.data.title);
    })
    },[])
   
// console.log(Data)
    return ( 
    <div>
         <input type="text"  defaultValue={Data} />
        
         <button>Edit Now</button>
    </div>
    );
}