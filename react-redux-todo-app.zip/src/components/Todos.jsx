import {store} from "../redux/store"
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import {Link} from "react-router-dom";
import {
  deleteTodoLoading,
    deleteTodoSuccess,
    addTodoLoading,
    addTodoSuccess,
    getTodoLoading,
    getTodoSuccess,
  } from "../redux/actions";
  import axios from "axios";

  import styled from "styled-components";

  const ResultDiv = styled.div`
  .box1{
  
    margin:auto;
     margin-top:50px;
    width:60%;
    height:auto;
    // border:1px solid red;
  }
  .box2{
    margin:auto;
      width:98%;
      height:30px;
      border:1px solid grey;
  }
  .bt{
    float:right;
    padding:4px;
    width:60px;
    margin-left:10px;
  }
  .todotext{
    float:left;
  }
  input{
    margin-top:50px;
    width:40%;
    height:33px;
  }
  #addtodo{
    width:9%;
   padding:12px;
   color:white;
   background-color: red;
   border:2px solid red;
  }
  a{
    text-decoration: none;
    color:white;
  }
  #btn1{
    color:white;
    background-color: blue;
    border:2px solid blue;
   
  }
  #btn2{
    color:white;
    background-color: green;
    border:2px solid green;
   
  }
  #btn3{
    color:white;
    background-color: red;
    border:2px solid red;
   
  }

`;

  export const Todos = () => {
    const { loading, data, error } = useSelector((store) => store.todos); 
    const dispatch = useDispatch();
  
    const [text, setText] = useState("");
  
    useEffect(() => {
      getTodos();
    }, []);

    const getTodos = () => {
        dispatch(getTodoLoading());
        axios.get("http://localhost:3001/todos").then(({ data }) => {
          dispatch(getTodoSuccess(data));
        });
      };
     

      let handleRemove = (e) => {
        dispatch(deleteTodoLoading())
        const id =e.id;
        // console.log(e)
        const url = "http://localhost:3001/todos/";
        axios.delete(url + id)
            .then(res => {
              dispatch(deleteTodoSuccess());
              getTodos()
                //console.log(res.data);
            })
            .catch((err) => {
                //console.log(err);
            })
    }
    
      return loading ? (
        "Loading...."
      ) : (
        <div>
          <ResultDiv>
          <input type="text" onChange={(e) => setText(e.target.value)} placeholder="Enter Todo"/>
          <button id="addtodo"
            onClick={() => {
              dispatch(addTodoLoading());
              axios
                .post("http://localhost:3001/todos", {
                  title: text,
                  status: false,
                })
                .then((data) => {
                  dispatch(addTodoSuccess());
                  getTodos();
                })
                .catch(() => {
                  dispatch(error)
                });
            }}
          >
            Add todo
          </button>
          <div className="box1">
            {data.map((e) => (
              <div className="box2" key={e.id}>
                <div className="todotext">{e.title}</div>
              <button className="bt" id="btn1" onClick={() => {
             
        }}><Link to={`/todo/${e.id}/edit`}>Edit</Link></button>

          <button className="bt" id="btn2" onClick={() => {
             
            }}><Link to={`/todo/${e.id}`}>Details</Link></button>
    
              <button className="bt" id="btn3" onClick={() => {
              handleRemove(e)
        }}>Delete</button>
              </div>
              
            ))}
          </div>
          </ResultDiv>
        </div>
      );
    };